import Navbar from "../Components/Navbar"
import BlogHero from "../Sections/BlogHero"

const Blog = () => {
  return (
    <>
    <Navbar />
    <BlogHero />
    </>
  )
}

export default Blog