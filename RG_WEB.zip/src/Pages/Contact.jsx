import Navbar from "../Components/Navbar"
import ContactHero from "../Sections/ContactHero"

const Contact = () => {
  return (
    <>
    <Navbar />
    <ContactHero />
    </>
  )
}

export default Contact
