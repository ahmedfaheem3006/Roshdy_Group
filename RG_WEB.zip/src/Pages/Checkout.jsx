import Navbar from "../Components/Navbar"
import CheckoutHero from "../Sections/CheckoutHero"

const Checkout = () => {
  return (
    <>
    <Navbar />
    <CheckoutHero />
    </>
  )
}

export default Checkout